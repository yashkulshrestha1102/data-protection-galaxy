// data/insights.ts
import { Shield, Globe, Users, Building, Database, Scale, BookOpen } from 'lucide-react';

export interface Insight {
  id: number;
  category: string;
  categoryIcon: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  readTime: string;
  slug: string;
  image?: string;
}

export const insightsData: Insight[] = [
  {
    id: 1,
    category: 'DPDP Act',
    categoryIcon: 'Shield',
    title: 'DPDP Act 2023: Director Liability, Board Responsibilities and Data Privacy Compliance for Indian Companies',
    excerpt: 'Are directors personally liable under India\'s DPDP Act 2023? What the Act actually says about penalties on the Data Fiduciary, why there are no criminal offences, and what boards should still do.',
    content: `
      <h2>Introduction</h2>
      <p>The Digital Personal Data Protection Act, 2023 (DPDP Act) introduces significant compliance obligations for companies operating in India. One of the most critical questions for corporate boards and directors is: <strong>Can directors be held personally liable for data protection failures?</strong></p>
      
      <h2>Director Liability under the DPDP Act</h2>
      <p>The DPDP Act imposes obligations on "data fiduciaries" — entities that determine the purpose and means of processing personal data. Monetary penalties are imposed on the Data Fiduciary after an inquiry by the Data Protection Board. The Act does not contain a separate provision that makes directors or officers personally liable for a company's contraventions, and it does not create criminal offences.</p>

      <h3>What this means in practice</h3>
      <ul>
        <li><strong>Penalties fall on the Data Fiduciary:</strong> up to ₹250 crore for failing to take reasonable security safeguards, with other tiers of ₹200 crore, ₹150 crore and ₹50 crore</li>
        <li><strong>No criminal liability under this Act:</strong> the DPDP Act imposes civil monetary penalties only</li>
        <li><strong>Company law still applies:</strong> directors owe duties of good faith and due care, and a serious breach can bring governance, shareholder and reputational consequences</li>
      </ul>

      <h2>Board Responsibilities</h2>
      <p>Boards must ensure that their organisations have robust data protection frameworks in place. This includes:</p>
      <p>For a complete understanding of the legal framework, read our <a href="/resources/guides/dpdpa-2023-complete-guide" class="text-blue-400 hover:text-blue-300 underline">DPDPA 2023 Complete Guide</a>.</p>
      <ul>
        <li>Appointing an India-based Data Protection Officer and an independent data auditor, if the company is notified as a Significant Data Fiduciary</li>
        <li>Implementing consent management mechanisms</li>
        <li>Carrying out periodic Data Protection Impact Assessments (a duty of Significant Data Fiduciaries)</li>
        <li>Establishing data breach response protocols</li>
      </ul>
      
      <h2>CEO Accountability</h2>
      <p>The CEO, as the chief executive officer of the company, bears ultimate responsibility for data protection compliance. CEOs must ensure that data protection is treated as a strategic priority, not just a legal obligation.</p>
      
      <h2>Compliance Requirements</h2>
      <p>Companies must comply with the following key requirements:</p>
      <ul>
        <li><strong>Notice and Consent:</strong> Provide clear notices and obtain valid consent</li>
        <li><strong>Data Security:</strong> Implement reasonable security safeguards</li>
        <li><strong>Data Breach Notification:</strong> Intimate the Board and affected individuals without delay, and give the Board a detailed report within 72 hours</li>
        <li><strong>Data Principal Rights:</strong> Enable individuals to exercise their rights</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>Directors and boards must take proactive steps to ensure compliance with the DPDP Act. Although the Act itself targets the Data Fiduciary, a large penalty or breach is a board-level risk, best managed through proper governance, training and robust data protection frameworks.</p>

      <h2>Related Reading</h2>
      <ul>
        <li><a href="/obligations" class="text-blue-400 hover:text-blue-300 underline">Obligations of Data Fiduciaries</a> — Board-level compliance responsibilities</li>
        <li><a href="/penalties" class="text-blue-400 hover:text-blue-300 underline">DPDPA Penalties</a> — What happens when boards fail to comply</li>
        <li><a href="/resources/guides/dpdpa-2023-complete-guide" class="text-blue-400 hover:text-blue-300 underline">DPDPA 2023 Complete Guide</a> — End-to-end guide to the Act</li>
      </ul>
    `,
    author: 'Vaibhav Pasrija',
    date: '22 Jul 2026',
    readTime: '8 min read',
    slug: 'dpdp-act-director-liability'
  },
  {
    id: 2,
    category: 'DPDP Act',
    categoryIcon: 'Shield',
    title: 'Data Breach Response & Notification Counsel under India\'s DPDP Act',
    excerpt: 'The DPDP Rule 7 breach-notification timeline, what to tell affected individuals and the Data Protection Board, the 72-hour detailed report and how organisations should prepare.',
    content: `
      <h2>Introduction</h2>
      <p>Data breaches are inevitable in today's digital landscape. The DPDP Act establishes clear timelines and requirements for breach notification. This article provides a comprehensive guide to data breach response under the DPDP Act.</p>
      
      <h2>DPDP Rule 7: Breach Notification Timeline</h2>
      <p>Under Rule 7 of the DPDP Rules, 2025, a data fiduciary must intimate the Data Protection Board and each affected Data Principal <strong>without delay</strong> on becoming aware of a breach, and then give the Board a detailed report within <strong>72 hours</strong> (or a longer period the Board allows).</p>
      
      <h2>What to Tell Affected Individuals</h2>
      <p>Affected individuals must be informed of the breach, including:</p>
      <p>To see a real-world example of how a failure to respond leads to severe consequences, check out our <a href="/resources/case-studies/data-breach-healthcare" class="text-blue-400 hover:text-blue-300 underline">Healthcare Data Breach Case Study</a>.</p>
      <ul>
        <li>The nature of the breach</li>
        <li>Type of data compromised</li>
        <li>Potential impact</li>
        <li>Remedial actions taken</li>
        <li>Contact details for queries</li>
      </ul>
      
      <h2>72-Hour Detailed Report</h2>
      <p>The detailed report to the Board must include:</p>
      <ul>
        <li>Cause of the breach</li>
        <li>Number of affected individuals</li>
        <li>Type of data compromised</li>
        <li>Immediate remedial actions</li>
        <li>Long-term preventive measures</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>Preparation is key to effective breach response. Organisations must invest in robust security infrastructure and have a well-documented incident response plan.</p>

      <h2>Related Reading</h2>
      <ul>
        <li><a href="/board" class="text-blue-400 hover:text-blue-300 underline">Data Protection Board of India</a> — Where you report breaches</li>
        <li><a href="/penalties" class="text-blue-400 hover:text-blue-300 underline">Penalties for Breach</a> — Up to ₹250 crore</li>
        <li><a href="/resources/case-studies/data-breach-healthcare" class="text-blue-400 hover:text-blue-300 underline">Healthcare Data Breach Case Study</a> — Real-world example</li>
      </ul>
    `,
    author: 'Shilpi Kulshrestha',
    date: '20 Jul 2026',
    readTime: '6 min read',
    slug: 'data-breach-response-dpdp'
  },
  {
    id: 3,
    category: 'GDPR',
    categoryIcon: 'Globe',
    title: 'GDPR Compliance: A Practical Guide for Indian Businesses Operating in the EU',
    excerpt: 'Understanding GDPR requirements for Indian companies with EU operations. Key obligations, data transfer mechanisms, and compliance strategies for cross-border data flows.',
    content: `
      <h2>Introduction</h2>
      <p>The General Data Protection Regulation (GDPR) applies to Indian companies that offer goods or services to individuals in the EU, or monitor their behaviour. This guide provides practical steps for Indian businesses to achieve GDPR compliance.</p>
      
      <h2>Key Obligations</h2>
      <ul>
        <li>Lawful processing of personal data</li>
        <li>Privacy by design and default</li>
        <li>Data protection impact assessments</li>
        <li>Appointment of Data Protection Officer (DPO)</li>
        <li>Maintaining records of processing</li>
        <li>Data subject rights</li>
      </ul>
      
      <h2>Data Transfer Mechanisms</h2>
      <p>Indian companies must use one of the following mechanisms to transfer data from the EU:</p>
      <p>To understand how India's local law handles this, read our <a href="/resources/guides/gdpr-vs-dpdpa" class="text-blue-400 hover:text-blue-300 underline">GDPR vs DPDPA Comparative Analysis</a>.</p>
      <ul>
        <li><strong>Adequacy Decision:</strong> EU has not yet issued an adequacy decision for India</li>
        <li><strong>Standard Contractual Clauses (SCCs):</strong> Most common mechanism</li>
        <li><strong>Binding Corporate Rules (BCRs):</strong> Suitable for multinational groups</li>
        <li><strong>Derogations:</strong> Limited exceptions</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>GDPR compliance is a journey, not a destination. Indian companies must adopt a proactive approach to data protection to build trust with EU customers and avoid significant penalties.</p>

      <h2>Related Reading</h2>
      <ul>
        <li><a href="/compare/dpdpa-vs-gdpr" class="text-blue-400 hover:text-blue-300 underline">DPDPA vs GDPR</a> — Full comparison</li>
        <li><a href="/resources/guides/gdpr-vs-dpdpa" class="text-blue-400 hover:text-blue-300 underline">GDPR vs DPDPA Guide</a> — Detailed guide</li>
        <li><a href="/cross-border" class="text-blue-400 hover:text-blue-300 underline">Cross-Border Transfers</a> — For Indian companies with EU operations</li>
      </ul>
    `,
    author: 'Shilpi Kulshrestha',
    date: '18 Jul 2026',
    readTime: '10 min read',
    slug: 'gdpr-compliance-guide'
  },
  {
    id: 4,
    category: 'Cross-Border',
    categoryIcon: 'Globe',
    title: 'Cross-Border Data Transfer: Mechanisms and Compliance under DPDP Act',
    excerpt: 'Exploring cross-border data transfer mechanisms under India\'s DPDP Act. Understanding adequacy decisions, standard contractual clauses, and binding corporate rules.',
    content: `
      <h2>Introduction</h2>
      <p>The DPDP Act regulates cross-border data transfers to ensure that personal data of Indian individuals is adequately protected when processed outside India.</p>
      <p>For a detailed breakdown of transfer mechanisms under the new Indian law, read our <a href="/resources/guides/cross-border-data-transfer" class="text-blue-400 hover:text-blue-300 underline">Cross-Border Data Transfer Guide</a>.</p>
      
      <h2>Adequacy Decisions</h2>
      <p>The Indian government may issue adequacy decisions for countries that provide an adequate level of data protection. Transfers to such countries do not require additional safeguards.</p>
      
      <h2>Standard Contractual Clauses (SCCs)</h2>
      <p>SCCs are model contractual clauses approved by the government that provide appropriate safeguards for cross-border data transfers.</p>
      
      <h2>Conclusion</h2>
      <p>Cross-border data transfers are a complex area of the DPDP Act. Organisations must carefully assess their transfer mechanisms and ensure compliance with the applicable requirements.</p>

      <h2>Related Reading</h2>
      <ul>
        <li><a href="/cross-border" class="text-blue-400 hover:text-blue-300 underline">Cross-Border Transfer (Core Topic)</a> — Section 16 deep dive</li>
        <li><a href="/resources/guides/cross-border-data-transfer" class="text-blue-400 hover:text-blue-300 underline">Cross-Border Transfer Guide</a> — Step-by-step compliance</li>
        <li><a href="/map" class="text-blue-400 hover:text-blue-300 underline">Global Privacy Map</a> — Compare 90+ countries</li>
      </ul>
    `,
    author: '	Shilpi Kulshrestha',
    date: '16 Jul 2026',
    readTime: '7 min read',
    slug: 'cross-border-data-transfer'
  },
  {
    id: 5,
    category: 'Data Rights',
    categoryIcon: 'Users',
    title: 'Data Subject Rights: A Comprehensive Guide for Data Fiduciaries',
    excerpt: 'Understanding the rights of data principals under the DPDP Act. Right to information, correction and erasure, grievance redressal and nomination.',
    content: `
      <h2>Introduction</h2>
      <p>The DPDP Act grants individuals (data principals) several rights to control their personal data. Data fiduciaries must understand and implement these rights.</p>
      
      <h2>Right to Access</h2>
      <p>Individuals have the right to obtain confirmation about whether their data is being processed, and access to the data along with information about the processing.</p>
      
      <h2>Conclusion</h2>
      <p>Data fiduciaries must implement robust processes to facilitate the exercise of these rights. This includes establishing dedicated teams, providing clear communication channels, and maintaining records of requests.</p>

      <h2>Related Reading</h2>
      <ul>
        <li><a href="/rights" class="text-blue-400 hover:text-blue-300 underline">Rights of Data Principals</a> — All 6 core rights explained</li>
        <li><a href="/data-principal-rights" class="text-blue-400 hover:text-blue-300 underline">Data Rights Request Form</a> — Exercise your rights</li>
        <li><a href="/grievance-redressal" class="text-blue-400 hover:text-blue-300 underline">Grievance Redressal</a> — How to file a complaint</li>
      </ul>
    `,
    author: 'Rojalin Panda',
    date: '14 Jul 2026',
    readTime: '9 min read',
    slug: 'data-subject-rights-guide'
  },
  {
    id: 6,
    category: 'Compliance',
    categoryIcon: 'Building',
    title: 'DPDP Act Compliance: A Practical Guide for Businesses in India',
    excerpt: 'How businesses can build DPDP Act 2023 compliance — notice, consent, security, breach response and governance — ahead of the DPDP Rules implementation.',
    content: `
      <h2>Introduction</h2>
      <p>As the DPDP Act 2023 is implemented, businesses must take proactive steps to ensure compliance. This guide provides a practical roadmap for businesses to achieve compliance.</p>
      
      <h2>1. Notice and Consent</h2>
      <ul>
        <li>Provide clear and concise privacy notices</li>
        <li>Obtain valid consent for processing personal data</li>
        <li>Enable individuals to withdraw consent</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>Compliance is an ongoing process. Businesses must stay informed about regulatory developments and continuously improve their data protection practices.</p>
    `,
    author: 'Rojalin Panda',
    date: '12 Jul 2026',
    readTime: '12 min read',
    slug: 'dpdp-compliance-guide'
  },
  {
    id: 7,
    category: 'Sector-Specific',
    categoryIcon: 'Database',
    title: 'Sector-Specific Data Protection Rules: Fintech, Healthtech, and E-Commerce',
    excerpt: 'Understanding sector-specific data protection requirements for fintech, healthtech, and e-commerce companies under India\'s data protection regime.',
    content: `
      <h2>Introduction</h2>
      <p>Different sectors face different data protection challenges. This article explores sector-specific requirements for fintech, healthtech, and e-commerce companies.</p>
      
      <h2>Fintech</h2>
      <ul>
        <li>RBI guidelines on data localisation</li>
        <li>KYC and AML compliance</li>
        <li>Fraud detection and prevention</li>
        <li>Consumer data protection</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>Sector-specific requirements add layers of complexity to data protection compliance. Companies must adopt a sector-agnostic approach while addressing sector-specific nuances.</p>
    `,
    author: 'Shilpi Kulshrestha',
    date: '10 Jul 2026',
    readTime: '6 min read',
    slug: 'sector-specific-data-protection'
  },
  {
    id: 8,
    category: 'AI & Automation',
    categoryIcon: 'Scale',
    title: 'AI and Data Protection: Navigating the Legal Landscape',
    excerpt: 'Exploring the intersection of artificial intelligence and data protection. Understanding algorithmic accountability, automated decision-making, and AI governance.',
    content: `
      <h2>Introduction</h2>
      <p>AI is transforming industries, but it also raises significant data protection challenges. This article explores the legal landscape for AI and data protection.</p>
      <p>To ensure your AI systems comply with the DPDPA, read our <a href="/resources/guides/dpdpa-2023-complete-guide" class="text-blue-400 hover:text-blue-300 underline">DPDPA 2023 Complete Guide</a>.</p>
      <h2>Algorithmic Accountability</h2>
      <ul>
        <li>Transparency in AI decision-making</li>
        <li>Explainability of AI outputs</li>
        <li>Bias and fairness in AI</li>
        <li>Human oversight</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>AI and data protection are increasingly intertwined. Organisations must adopt a governance-first approach to AI development and deployment.</p>
    `,
    author: 'Shilpi Kulshrestha',
    date: '8 Jul 2026',
    readTime: '8 min read',
    slug: 'ai-and-data-protection'
  },
  {
    id: 9,
    category: 'DPDP Act',
    categoryIcon: 'Shield',
    title: 'Significant Data Fiduciary (SDF) Readiness: DPIA and Audit under DPDP Act',
    excerpt: 'What makes an organisation a Significant Data Fiduciary? Enhanced obligations under Section 10 and Rule 13, India-based DPO, independent auditor, and annual compliance requirements.',
    content: `
      <h2>Introduction</h2>
      <p>Not all data fiduciaries are created equal. The DPDP Act imposes enhanced obligations on certain entities designated as "Significant Data Fiduciaries" (SDFs).</p>
      
      <h2>What Makes an Organisation an SDF?</h2>
      <ul>
        <li>Volume of personal data processed</li>
        <li>Type of personal data processed</li>
        <li>Risk of harm to data principals</li>
        <li>Geographic reach</li>
        <li>Sectoral sensitivity</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>SDFs must invest in robust compliance frameworks to meet enhanced obligations. This includes dedicated resources, expert guidance, and ongoing monitoring.</p>
    `,
    author: 'Shilpi Kulshrestha',
    date: '6 Jul 2026',
    readTime: '11 min read',
    slug: 'significant-data-fiduciary-readiness'
  },
  {
    id: 10,
    category: 'DPDP Act',
    categoryIcon: 'Shield',
    title: 'Data Protection Officer (DPO) Services in India under the DPDP Act',
    excerpt: 'When the DPDP Act requires a Data Protection Officer, what the role involves, and how organisations can prepare for DPO appointment and responsibilities.',
    content: `
      <h2>Introduction</h2>
      <p>The DPDP Act introduces the role of Data Protection Officer (DPO) for certain data fiduciaries. This article explores the requirements and responsibilities of the DPO.</p>
      
      <h2>When is a DPO Required?</h2>
      <ul>
        <li>Significant Data Fiduciaries (SDFs)</li>
        <li>Data fiduciaries with high-volume processing</li>
        <li>Data fiduciaries processing sensitive data</li>
        <li>Designated by the Board</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>The DPO plays a critical role in ensuring DPDP Act compliance. Organisations must invest in DPO appointment and support to build a robust data protection framework.</p>
    `,
    author: 'Vaibhav Pasrija',
    date: '4 Jul 2026',
    readTime: '5 min read',
    slug: 'dpo-services-india'
  },
  {
    id: 11,
    category: 'Data Rights',
    categoryIcon: 'Users',
    title: 'Click-Wrap Agreements and India\'s Data Privacy Law: Aligning Digital Consent',
    excerpt: 'The architecture of modern digital commerce rests on an unassuming yet powerful legal device: the click-wrap agreement. Understanding digital consent under the DPDP framework.',
    content: `
      <h2>Introduction</h2>
      <p>The architecture of modern digital commerce rests on an unassuming yet powerful legal device: the click-wrap agreement. Whether subscribing to a service, downloading an app, or making a purchase, users routinely click "I agree" to terms that are often lengthy and technical.</p>
      
      <h2>Judicial Trends and Comparative Insights</h2>
      <p>While Indian jurisprudence on data protection is still evolving, global developments offer instructive parallels. Courts and regulators in jurisdictions such as the <strong>European Union</strong> have increasingly invalidated consent mechanisms that rely on pre-ticked boxes, vague language or bundled permissions.</p>
      
      <h2>Conclusion</h2>
      <p>As India's digital economy expands, the convergence of contract law and data protection will continue to shape how agreements are formed, interpreted, and enforced. Click-wrap agreements, once a symbol of convenience, must now evolve into <strong>instruments of informed choice</strong>.</p>
    `,
    author: 'Shilpi Kulshrestha',
    date: '2 Jul 2026',
    readTime: '7 min read',
    slug: 'click-wrap-agreements-consent'
  },
  {
    id: 12,
    category: 'International',
    categoryIcon: 'Globe',
    title: 'Global Data Protection Laws: A Comparative Analysis',
    excerpt: 'Comparing data protection frameworks across jurisdictions — GDPR, DPDP Act, CCPA/CPRA, LGPD, PIPL, and POPIA. Understanding the global regulatory landscape.',
    content: `
      <h2>Introduction</h2>
      <p>Data protection laws are evolving rapidly across the globe. This article provides a comparative analysis of major data protection frameworks.</p>
      
      <h2>European Union: GDPR</h2>
      <ul>
        <li>Comprehensive rights for data subjects</li>
        <li>Strict obligations for controllers and processors</li>
        <li>Extraterritorial applicability</li>
        <li>Significant penalties (up to €20 million or 4% of global turnover)</li>
      </ul>
      
      <h2>Conclusion</h2>
      <p>While each framework has its unique features, there is convergence around key principles: individual rights, accountability, and transparency. Multinational organisations must navigate this complex landscape with care.</p>
    `,
    author: 'Vaibhav Pasrija',
    date: '30 Jun 2026',
    readTime: '15 min read',
    slug: 'global-data-protection-laws'
  },


    {
    id: 13,
    category: 'DPDP Act',
    categoryIcon: 'Shield',
    title: 'DPDP (Removal of Difficulties) Order, 2026: Key Amendments to Sections 9(1) and 10(2)(c)(ii)',
    excerpt: 'MeitY has issued the Digital Personal Data Protection (Removal of Difficulties) Order, 2026, clarifying textual ambiguities in Sections 9(1) and 10(2)(c)(ii) of the DPDP Act, 2023. Here\'s what businesses need to know.',
    content: `
      <h2>Introduction</h2>
      <p>The Ministry of Electronics and Information Technology (MeitY), Government of India, has issued the <strong>Digital Personal Data Protection (Removal of Difficulties) Order, 2026</strong>, dated 5 October 2026 and published in the Official Gazette on 7 October 2026. The Order addresses textual ambiguities in the Digital Personal Data Protection Act, 2023.</p>

      <h2>Key Amendments</h2>

      <h3>1. Section 9(1): Processing of Personal Data of Children and Persons with Disabilities</h3>
      <p>The Order clarifies the wording concerning the personal data of children and persons with disabilities who have lawful guardians, reinforcing the intended application of <strong>verifiable parental or lawful-guardian consent</strong> requirements.</p>
      <p><strong>Business Impact:</strong> Businesses processing such personal data should review their consent collection mechanisms, guardian verification procedures and supporting documentation.</p>

      <h3>2. Section 10(2)(c)(ii): Periodic Data Audits</h3>
      <p>The Order replaces the word <strong>"audit" with "data audit"</strong> in the provision concerning periodic audits by Significant Data Fiduciaries (SDFs), clarifying the intended scope of the audit requirement.</p>
      <p><strong>Business Impact:</strong> SDFs should review their data-audit processes and compliance frameworks to ensure alignment with the clarified provision.</p>

      <h2>What Should Businesses Do?</h2>
      <ul>
        <li>Assess the applicability of these amendments to their operations</li>
        <li>Review relevant privacy and consent procedures</li>
        <li>Ensure that data-governance and audit frameworks remain aligned with the DPDP Act and applicable rules</li>
      </ul>
      <p>The Order primarily addresses <strong>textual and interpretative ambiguities</strong>, rather than introducing an entirely new set of compliance obligations.</p>

      <h2>Read the Official Order</h2>
<p>For the complete text, refer to the <strong>Digital Personal Data Protection (Removal of Difficulties) Order, 2026</strong> — <a href="https://egazette.gov.in/WriteReadData/2026/276885.pdf" target="_blank" rel="noopener noreferrer" class="text-blue-400 underline hover:text-blue-300">Official Gazette notification (S.O. 5458(E))</a>.</p>
      <p><em>This update is for general informational purposes and should not be construed as legal advice.</em></p>
    `,
    author: 'Rojalin Panda',
    date: '7 Oct 2026',
    readTime: '4 min read',
    slug: 'dpdp-removal-of-difficulties-order-2026'
  },
];

export const categories = [
  { id: 'all', label: 'All Insights', icon: BookOpen },
  { id: 'DPDP Act', label: 'DPDP Act', icon: Shield },
  { id: 'GDPR', label: 'GDPR', icon: Globe },
  { id: 'Cross-Border', label: 'Cross-Border', icon: Globe },
  { id: 'Data Rights', label: 'Data Rights', icon: Users },
  { id: 'Compliance', label: 'Compliance', icon: Building },
  { id: 'Sector-Specific', label: 'Sector-Specific', icon: Database },
  { id: 'AI & Automation', label: 'AI & Automation', icon: Scale },
  { id: 'International', label: 'International', icon: Globe },
];

export const getInsightBySlug = (slug: string) => {
  return insightsData.find(insight => insight.slug === slug);
};

export const getRelatedInsights = (slug: string, limit: number = 3) => {
  const current = getInsightBySlug(slug);
  if (!current) return [];
  return insightsData
    .filter(i => i.id !== current.id && i.category === current.category)
    .slice(0, limit);
};
